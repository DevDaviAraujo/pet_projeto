

                            <form id="form_adjetivo_cadastro" class="max-w-36" action="/cadastrar/adjetivo" autocomplete="off" method="post">   
                                <label for="default-search" class="mb-2 text-base font-medium text-green-900 sr-only text-white">Search</label>
                                <div class="relative">

                                    <input type="hidden" name="idPets" value="<?php echo e($pet->id); ?>">
                                    <input type="search" maxlength="15" name="texto" id="default-search" class="pe-10 block w-full text-sm text-green-900 border border-green-300 rounded-lg bg-green-600 focus:ring-green-500 focus:border-green-600 text-white focus:ring-green-600 focus:border-green-600" placeholder="Fofo"/>
                                    
                                    <?php echo csrf_field(); ?>

                                    
                                    <button type="submit" class="text-white absolute end-2 bottom-1 bg-green-600 hover:bg-green-800  font-medium rounded-lg text-sm  ">
                                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAABXUlEQVR4nO2WvUrDUBSAs/gIDv5UBBeHOukoOAsqgm9hbX0FX6FjUTp0dK/6JkYKrqKbjZstnxw4hTvk/kd06AeBJDe5H/fknHNTFEv+G8AW0AWegBL40qPUe1dAq0nhBjAAZviZA/fAdq70HKiIZwqcpUqvdQWpyLu9lJXOM6SmPGzlwGZieF1hXw8RD2me25CSCcneWGYSSZdY6jSHd2AfOKwZ67jEj5nSts5zUDM+doknidIPYE/n2AXeap4pXeLql6RC5RJL6tdxobUtvdkW3rZe25i6xC+Wl3Z0/MiQx0i9obYl12RRDip/jZR6k0u2NgLkK5FS4dIlbnkaiCmPkX47G4hOeOeZRMJ8o9kcysApNTZ+W3an8AmsecUqP26oZ8u2eBokNeS9Bn4EulHSBbKJJ4ZdwntS5ACsAn3NzJBVjoK/acSfSQd4AJ61r1d6PpY69ZbMkuIP+AFd7iP6smOiuQAAAABJRU5ErkJggg==">
                                    </button>
                                </div>
                            </form>
                        

                            <?php $__currentLoopData = $pet->adjetivos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adjetivo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                                <form id="form_adjetivo_excluir" class="max-w-36" action="/excluir/adjetivo" autocomplete="off" method="post">   
                                    <label for="default-search" class="mb-2 text-base font-medium text-green-900 sr-only text-white">Search</label>
                                    <div class="relative">

                                        <input type="hidden" name="id" value="<?php echo e($adjetivo->id); ?>">
                                        <input disabled type="search" maxlength="15" name="texto" value="<?php echo e($adjetivo->texto); ?>" id="default-search" class="pe-10 block w-full text-sm text-green-900 border border-green-300 rounded-lg bg-green-600 focus:ring-green-500 focus:border-green-600 text-white focus:ring-green-600 focus:border-green-600" placeholder="Fofo"/>
                                        
                                        <?php echo csrf_field(); ?>

                                        
                                        <button type="submit" class="text-white absolute end-2 bottom-1 bg-green-600 hover:bg-green-800  font-medium rounded-lg text-sm  ">
                                            <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAYAAADgdz34AAAACXBIWXMAAAsTAAALEwEAmpwYAAABBklEQVR4nN2VTQrCQAxGBbFncVFXulMP4U/xTuotlHokFXVbsTvR/ZPAFCWknVoV0QcDQzL9EpKZtFb7a4AAmAArYANc3ZJ97HxBVfExcMCPnBk+I1wH5jzPTL4tE6CKeMbMJz7idYZFDdU17wId4GQIia0N9JR9bzbe3QhN2/lCFUT2ofNJAprICiBXUZMCLedvAolhOxrfLa0AW+OgzjZUe6t0wsYKcCGfNMvak3nG5R0BkoLz56+UKC7KnHtZrMZrFl+5poHx0Hqehya+vrLvciesPHNeZ2CKv2nYTQvFH8a1jN7PjGtVrn0J4Z23LHm4xkcyW4C1e4yyZC82+es1Kon/DDdik9w/6UChUgAAAABJRU5ErkJggg==">
                                        </button>
                                    </div>
                                </form>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                   <?php /**PATH C:\xampp\htdocs\pet_projeto\resources\views/website/refreshable.blade.php ENDPATH**/ ?>